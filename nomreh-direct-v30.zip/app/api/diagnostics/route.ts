import { NextResponse } from "next/server";
import { ACCEPTED_FILE_LABEL } from "@/lib/file-constraints";
import { AuthError, requireAdmin } from "@/lib/server/auth";
import { getProviderConfig } from "@/lib/server/provider-config";
import { providerByteLimit } from "@/lib/server/provider-traits";
import { regionBlockWarning } from "@/lib/server/region-block";
import { checkGeminiRelay } from "@/lib/server/relay-check";
import { pageRenderSettings } from "@/lib/server/pdf-vision";
import { textOnlyReason, visionVerdict } from "@/lib/server/vision-capability";

export const runtime = "nodejs";

/**
 * "Is this thing actually wired up?" — answered without spending a token.
 *
 * Administrator-only by design: it names the provider, the model and the size limits,
 * which is configuration, not something a teacher should see in their own panel. The
 * teacher-facing answer to "why did my sheet fail" is the error message on the action
 * itself, in plain language, with the reason already named.
 *
 * The teacher kept receiving one sentence that could mean six different things, and
 * the only way to tell them apart was for someone to read the server log. This endpoint
 * reports what the server knows about itself: which provider and model are configured,
 * whether a key is present (never the key), what the size limits are, how long a call
 * may run, and whether the last refusal was a country block. It makes no provider
 * request, so opening it costs nothing.
 */
export async function GET(request: Request) {
  try {
    await requireAdmin();
    const relayRequested = new URL(request.url).searchParams.get("relay") === "1";
    let provider: Awaited<ReturnType<typeof getProviderConfig>> | null = null;
    let providerError = "";
    try {
      provider = await getProviderConfig();
    } catch (error) {
      providerError = error instanceof Error ? error.message : "خواندن تنظیمات سرویس ناموفق بود.";
    }

    const configuredTimeout = Number(process.env.NOMREH_PROVIDER_TIMEOUT_MS || "");
    const timeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout >= 15_000 ? Math.min(configuredTimeout, 600_000) : 120_000;
    // One page's real cost, from the same function that renders it: the operator
    // asked for 3000 px, and the advice about how many pages fit in one request has
    // to follow that number instead of a constant captured at an older resolution.
    const render = pageRenderSettings();
    const singlePageBudget = render.estimatedPageBytes;

    return NextResponse.json({
      ok: !providerError && Boolean(provider?.provider && provider?.model && provider?.apiKey),
      provider: provider ? { id: provider.provider, model: provider.model, hasKey: Boolean(provider.apiKey) } : null,
      providerError: providerError || undefined,
      limits: {
        acceptedFiles: ACCEPTED_FILE_LABEL,
        requestBytes: providerByteLimit(provider?.provider ?? "gemini"),
        timeoutMs,
        // Above this, the page is likely to run past the proxy's patience.
        // Capped by the app's own page limits, not just by bytes: 25 MB of budget
        // divided by a 147 KB page suggests 167 pages, while the pipeline refuses
        // anything past 20 per PDF and 30 per request. Advice that contradicts the
        // refusal it is meant to prevent is worse than no advice.
        pagesPerRequestAdvice: Math.max(1, Math.min(20, Math.floor(providerByteLimit(provider?.provider ?? "gemini") / singlePageBudget))),
        // Reading detail: how big each page image is now, and how much of it the
        // model actually gets to see. Lower this if requests time out; raise it if
        // handwriting or fractions are still being misread.
        render: { pageMaxPx: render.maxPx, jpegQuality: render.jpegQuality, estimatedPageBytes: render.estimatedPageBytes },
      },
      // Two warnings that cost nothing and explain most "it does not work" reports:
      // a country block, and a model that cannot see the pages at all.
      warning: provider ? regionBlockWarning(provider.provider) : null,
      // Gemini only, and only when asked (`?relay=1`): the operator's last real
      // blocker was the country block, and after deploying a relay the useful
      // question is whether the address they typed reaches Google or dies in
      // Cloudflare. This GET is unauthenticated and sends no key, so it cannot be
      // billed; it is opt-in so opening the panel stays instant.
      relay: provider?.provider === "gemini" && relayRequested ? await checkGeminiRelay() : undefined,
      visionWarning: provider ? (() => {
        const reason = textOnlyReason(provider.model);
        return reason ? `${reason}. خواندن برگه و تصحیح با این مدل کار نمی‌کند؛ مدلی با پشتیبانی تصویر انتخاب کنید.` : null;
      })() : null,
      // The single most useful verdict for the operator: will this exact model accept
      // a photographed sheet? false means every request will be refused for its image.
      // One verdict, computed from the same list the request path enforces, so the
      // panel and the refusal sentence can never contradict each other.
      vision: provider ? { verdict: visionVerdict(provider.model), blocksSheets: visionVerdict(provider.model) === "no" } : null,
      // The one check that catches the most common host problem: a process started
      // before the current build, where the code behaves nothing like the docs.
      buildId: process.env.NOMREH_BUILD_ID || null,
      role: "admin",
      note: "این گزارش هیچ درخواستی به سرویس هوش مصنوعی نمی‌فرستد و هیچ توکنی مصرف نمی‌کند.",
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const status = error instanceof AuthError ? error.status : 500;
    return NextResponse.json({ error: error instanceof Error ? error.message : "بررسی آمادگی ناموفق بود." }, { status });
  }
}
