1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
a:I[484,[],"OutletBoundary"]
b:"$Sreact.suspense"
e:"ViewportBoundary"
f:I[484,[],"$e"]
10:"MetadataBoundary"
11:I[484,[],"$10"]
12:I[6869,[],"IconMark"]
:HL["/_next/static/css/5fbc850037caf3d4.css","style"]
:HL["/_next/static/css/392e3586ab63bffc.css","style"]
:HL["/_next/static/css/59a51952af54357c.css","style"]
5:X
8:X
8:C
9:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],null,["$","$La",null,{"children":["$","$b",null,{"name":"Next.MetadataOutlet","children":"$@c"}]}]]}],"p":"$@d","v":null,"s":"$5"}}]]
6:[["children",{"s":"_not-found","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"p":"$@7","v":"$8","s":"$5"},"c":"$Q9"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/5fbc850037caf3d4.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/392e3586ab63bffc.css","precedence":"next"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/css/59a51952af54357c.css","precedence":"next"}]],["$","html",null,{"lang":"fa","dir":"rtl","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]}]]}],"p":"$@4","v":null,"s":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$Lf",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#123b35"}]]}],["$","$L11",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$b",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"نمره | دستیار تصحیح آزمون"}],["$","meta","1",{"name":"description","content":"تصحیح هوشمند برگه‌های امتحانی با حساب معلم، کلاس‌بندی، بارم دقیق و بازبینی انسانی."}],["$","link","2",{"rel":"icon","href":"/nomreh-mark.svg"}],["$","$L12","3",{}]]}]}],null]}],null]}],"p":"$@13","v":null,"s":"$5"}},"a":"$@14","u":"$@15","b":"2ouU2GAI7Uo3hztfk2Bcm"}
c:null
5:300
15:true
5:C
14:0
7:"$undefined"
4:"$undefined"
13:"$undefined"
d:"$undefined"
