exports.id=3668,exports.ids=[3668,4579],exports.modules={59645:(a,b,c)=>{"use strict";c.d(b,{Jd:()=>j,M7:()=>g,SM:()=>i,p8:()=>f});let d=globalThis,e=d.__nomrehProviderFailures||[];function f(a){e.unshift({...a,detail:String(a.detail).replace(/sk-[A-Za-z0-9_-]{6,}/g,"[کلید]").replace(/AIza[A-Za-z0-9_-]{10,}/g,"[کلید]").replace(/Bearer\s+[A-Za-z0-9._-]{10,}/gi,"Bearer [کلید]").replace(/\s+/g," ").trim().slice(0,240),at:new Date().toISOString()}),e.length>40&&(e.length=40)}function g(){return[...e]}d.__nomrehProviderFailures=e;let h=d.__nomrehProviderStreak||new Map;function i(a,b){h.set(a,b?0:(h.get(a)||0)+1)}function j(){return[...h.entries()].map(([a,b])=>({provider:a,consecutiveFailures:b}))}d.__nomrehProviderStreak=h},78335:()=>{},79015:(a,b,c)=>{"use strict";let d;c.d(b,{MP:()=>s,Qt:()=>o,Pf:()=>r,Xp:()=>t,Pp:()=>q});var e=c(73024),f=c.n(e),g=c(76760),h=c.n(g),i=c(84579);let j=new Map,k=Number.isInteger(d=Number(process.env.NOMREH_OUTBOUND_WINDOW_LIMIT||""))&&d>0?d:120,l=function(a){let b=a.now||(()=>Date.now()),c=h().join(a.dataDirectory,"outbound-window.json");function d(){try{let a=JSON.parse(f().readFileSync(c,"utf8"));if(!a||!Array.isArray(a.hits))return{hits:[]};return{hits:a.hits.filter(a=>"number"==typeof a)}}catch{return{hits:[]}}}function e(b,c){let d=c-a.windowMs;return{hits:b.hits.filter(a=>a>d)}}let g={hits:[]};return{take(){let i,j=b(),k=b=>{let c=e(b,j);if(c.hits.length>=a.max){let b=Math.max(0,(c.hits[0]??j)+a.windowMs-j);return i={ok:!1,used:c.hits.length,limit:a.max,remaining:0,retryAfterMs:b},c}return c.hits.push(j),i={ok:!0,used:c.hits.length,limit:a.max,remaining:Math.max(0,a.max-c.hits.length),retryAfterMs:0},c};try{f().mkdirSync(a.dataDirectory,{recursive:!0}),function(a,b){let c=h().join(a,"outbound-window.lock"),d=!1;for(let a=0;a<40&&!d;a+=1)try{f().mkdirSync(c),d=!0}catch{try{Date.now()-f().statSync(c).mtimeMs>5e3&&f().rmdirSync(c)}catch{}let a=Date.now()+25;for(;Date.now()<a;);}try{return b()}finally{if(d)try{f().rmdirSync(c)}catch{}}}(a.dataDirectory,()=>{var b=k(d());try{f().mkdirSync(a.dataDirectory,{recursive:!0});let d=`${c}.${process.pid}.tmp`;f().writeFileSync(d,JSON.stringify(b)),f().renameSync(d,c)}catch{}})}catch{g=k(e(g,j))}return i||{ok:!0,used:0,limit:a.max,remaining:a.max,retryAfterMs:0}},snapshot(){let c=b(),f=0;try{f=e(d(),c).hits.length}catch{f=e(g,c).hits.length}return{used:f,limit:a.max,remaining:Math.max(0,a.max-f),windowMinutes:Math.round(a.windowMs/6e4)}}}}({dataDirectory:i.DATA_DIRECTORY,max:k,windowMs:12e5});function m(a){let b=j.get(a);return b||(b={hits:[],active:0,failures:0,openUntil:0},j.set(a,b)),b}class n extends Error{constructor(a,b,c=0){super(a),this.name="ProviderRateLimitError",this.code=b,this.retryAfterMs=c}}function o(){return r([...j.keys()])}function p(a,b){let c=b-12e5;for(;a.hits.length&&a.hits[0]<c;)a.hits.shift()}async function q(a,b){let c=m(a),d=Date.now();if(p(c,d),c.openUntil>d){let b=Math.ceil((c.openUntil-d)/6e4);throw new n(`ارتباط با ${a} موقتاً متوقف شده است: چند تلاش پیاپی شکست خورد و برای جلوگیری از مسدودشدن سرور، تا ${b} دقیقهٔ دیگر درخواستی ارسال نمی‌شود.`,"PROVIDER_BREAKER_OPEN",c.openUntil-d)}let e=l.take();if(!e.ok)throw new n(`سقف کل خروجی سرور در ۲۰ دقیقه پر شده است (${e.limit} درخواست برای همهٔ مقصدها). برای جلوگیری از مسدودشدن کامل خروجی، ${Math.ceil(e.retryAfterMs/6e4)} دقیقهٔ دیگر تلاش کنید.`,"PROVIDER_RATE_LIMITED",e.retryAfterMs);if(c.hits.length>=120){let b=c.hits[0]+12e5-d;throw new n(`سقف مجاز درخواست به ${a} در ۲۰ دقیقه پر شده است (120 درخواست). برای جلوگیری از مسدودشدن خروجی سرور، ${Math.ceil(b/6e4)} دقیقهٔ دیگر تلاش کنید.`,"PROVIDER_RATE_LIMITED",b)}let f=0;for(;c.active>=2&&f<3e4;)await new Promise(a=>setTimeout(a,200)),f+=200;c.active+=1,c.hits.push(d);try{let a=await b();return c.failures=0,a}catch(b){let a=b?.code||b?.cause?.code||"";throw/^(UND_ERR|ECONN|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH|EAI_AGAIN|ENOTFOUND)/.test(a)&&(c.failures+=1,c.failures>=5&&(c.openUntil=Date.now()+6e5,c.failures=0)),b}finally{c.active=Math.max(0,c.active-1)}}function r(a){let b=Date.now();return a.map(a=>{let c=m(a);p(c,b);let d=c.hits.length;return{hostname:a,used:d,limit:120,remaining:Math.max(0,120-d),windowMinutes:20,active:c.active,breakerOpen:c.openUntil>b,breakerMinutesLeft:c.openUntil>b?Math.ceil((c.openUntil-b)/6e4):0,failures:c.failures,nextSlotInSeconds:d>0?Math.max(0,Math.round((c.hits[0]+12e5-b)/1e3)):0,percentUsed:Math.round(d/120*100)}})}let s={windowMs:12e5,maxPerWindow:120,maxConcurrency:2};function t(){return l.snapshot()}},84579:(a,b,c)=>{"use strict";c.r(b),c.d(b,{DATA_DIRECTORY:()=>k,createId:()=>n,getDb:()=>m});var d=c(55511),e=c(29021),f=c(33873),g=c.n(f),h=c(80099);class i extends h.DatabaseSync{prepare(a){return super.prepare(a)}pragma(a){return this.prepare(`PRAGMA ${a}`).get()}transaction(a){return(...b)=>{this.exec("BEGIN");try{let c=a(...b);return this.exec("COMMIT"),c}catch(a){try{this.exec("ROLLBACK")}catch{}throw a}}}}var j=c(90773);let k=process.env.NOMREH_DATA_DIR||g().join(process.cwd(),"data");(0,e.mkdirSync)(k,{recursive:!0});let l=globalThis;function m(){return l.__nomrehDatabase||(l.__nomrehDatabase=function(){let a=new i(g().join(k,"nomreh.db"));for(let b of(a.pragma("journal_mode = WAL"),a.pragma("foreign_keys = ON"),a.pragma("busy_timeout = 5000"),a.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin', 'teacher', 'reviewer')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS provider_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      encrypted_api_key TEXT NOT NULL,
      key_hint TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      updated_by TEXT REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS workspaces (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      data_json TEXT NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ai_jobs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      submission_id TEXT,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      status TEXT NOT NULL,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      latency_ms INTEGER NOT NULL DEFAULT 0,
      error TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_ai_jobs_user ON ai_jobs(user_id);
    CREATE INDEX IF NOT EXISTS idx_ai_jobs_created ON ai_jobs(created_at);
  `),a.exec(`CREATE TABLE IF NOT EXISTS kaya_egress (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    bind_address TEXT NOT NULL DEFAULT '',
    host TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL,
    updated_by TEXT REFERENCES users(id)
  )`),a.prepare("PRAGMA table_info(workspaces)").all().some(a=>"revision"===a.name)||a.exec("ALTER TABLE workspaces ADD COLUMN revision INTEGER NOT NULL DEFAULT 0"),["v2ray_configs","v2ray_settings","api_network_settings"]))a.exec(`DROP TABLE IF EXISTS ${b}`);if(a.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(new Date().toISOString()),0===a.prepare("SELECT COUNT(*) AS count FROM users").get().count){let b=new Date().toISOString();a.transaction(()=>{a.prepare(`INSERT INTO users (id, username, display_name, password_hash, role, active, created_at)
        VALUES (?, ?, ?, ?, 'admin', 1, ?)`).run((0,d.randomUUID)(),process.env.NOMREH_ADMIN_USERNAME||"admin","مدیر سامانه",(0,j.Er)(process.env.NOMREH_ADMIN_PASSWORD||"Admin@1405"),b),a.prepare(`INSERT INTO users (id, username, display_name, password_hash, role, active, created_at)
        VALUES (?, ?, ?, ?, 'teacher', 1, ?)`).run((0,d.randomUUID)(),process.env.NOMREH_TEACHER_USERNAME||"teacher","معلم نمونه",(0,j.Er)(process.env.NOMREH_TEACHER_PASSWORD||"Teacher@1405"),b)})()}return a}()),l.__nomrehDatabase}function n(a){return`${a}_${(0,d.randomUUID)()}`}},90773:(a,b,c)=>{"use strict";c.d(b,{BE:()=>f,Er:()=>e,d7:()=>g});var d=c(55511);function e(a){let b=(0,d.randomBytes)(16),c=(0,d.scryptSync)(a,b,64);return`${b.toString("hex")}:${c.toString("hex")}`}function f(a,b){let[c,e]=b.split(":");if(!c||!e)return!1;try{let b=Buffer.from(e,"hex"),f=(0,d.scryptSync)(a,Buffer.from(c,"hex"),b.length);return b.length===f.length&&(0,d.timingSafeEqual)(b,f)}catch{return!1}}function g(a){return a.length>=8&&/[A-Za-z\u0600-\u06FF]/.test(a)&&/\d/.test(a)}},96487:()=>{},96942:(a,b,c)=>{"use strict";c.d(b,{HW:()=>m,JR:()=>n,QF:()=>j,ZT:()=>o,fF:()=>i,iJ:()=>p,jw:()=>k,lR:()=>h,lx:()=>l});var d=c(55511),e=c(65573),f=c(90773);let g="nomreh_session";class h extends Error{constructor(a="برای ادامه وارد حساب شوید.",b=401){super(a),this.status=b}}function i(a){return{id:a.id,username:a.username,displayName:a.display_name,role:a.role,active:!!a.active,createdAt:a.created_at,lastLoginAt:a.last_login_at||void 0}}async function j(a,b){let d=(await c.e(4579).then(c.bind(c,84579))).getDb(),e=d.prepare("SELECT * FROM users WHERE username = ? COLLATE NOCASE").get(a.trim());if(!e||!e.active||!(0,f.BE)(b,e.password_hash))return null;let g=new Date().toISOString();return d.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(g,e.id),i({...e,last_login_at:g})}async function k(a){let b=(0,d.randomBytes)(32).toString("base64url"),f=new Date,h=new Date(f.getTime()+6048e5),i=[(0,d.randomBytes)(16).toString("hex"),(0,d.createHash)("sha256").update(b).digest("hex"),a,h.toISOString(),f.toISOString(),f.toISOString()];return(await c.e(4579).then(c.bind(c,84579))).getDb().prepare(`INSERT INTO sessions (id, token_hash, user_id, expires_at, created_at, last_seen_at)
    VALUES (?, ?, ?, ?, ?, ?)`).run(...i),(await (0,e.UL)()).set(g,b,{httpOnly:!0,sameSite:"lax",secure:"0"!==process.env.NOMREH_COOKIE_SECURE,path:"/",expires:h}),b}async function l(){let a=await (0,e.UL)(),b=a.get(g)?.value;if(b){let a=(0,d.createHash)("sha256").update(b).digest("hex");(await c.e(4579).then(c.bind(c,84579))).getDb().prepare("DELETE FROM sessions WHERE token_hash = ?").run(a)}a.delete(g)}async function m(){let a=await (0,e.UL)(),b=a.get(g)?.value;if(!b)return null;let f=(0,d.createHash)("sha256").update(b).digest("hex"),h=new Date().toISOString(),j=`SELECT u.*, s.id AS session_id, s.expires_at, s.last_seen_at
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > ? AND u.active = 1`,k=(await c.e(4579).then(c.bind(c,84579))).getDb().prepare(j).get(f,h);return k?(Date.now()-new Date(k.last_seen_at).getTime()>3e5&&(await c.e(4579).then(c.bind(c,84579))).getDb().prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(h,k.session_id),i(k)):null}async function n(){let a=await m();if(!a)throw new h;return a}async function o(){let a=await n();if("admin"!==a.role)throw new h("این بخش فقط برای مدیر سامانه است.",403);return a}async function p(){let a=await n();if("admin"===a.role)throw new h("حساب مدیریت فقط به کاربران، مصرف و تنظیمات اتصال دسترسی دارد.",403);return a}}};