"use strict";exports.id=8630,exports.ids=[8630],exports.modules={48630:(a,b,c)=>{c.r(b),c.d(b,{DATA_DIRECTORY:()=>k,createId:()=>n,getDb:()=>m});var d=c(55511),e=c(29021),f=c(33873),g=c.n(f),h=c(80099);class i extends h.DatabaseSync{prepare(a){return super.prepare(a)}pragma(a){return this.prepare(`PRAGMA ${a}`).get()}transaction(a){return(...b)=>{this.exec("BEGIN");try{let c=a(...b);return this.exec("COMMIT"),c}catch(a){try{this.exec("ROLLBACK")}catch{}throw a}}}}function j(a){let b=(0,d.randomBytes)(16),c=(0,d.scryptSync)(a,b,64);return`${b.toString("hex")}:${c.toString("hex")}`}let k=process.env.NOMREH_DATA_DIR||g().join(process.cwd(),"data");(0,e.mkdirSync)(k,{recursive:!0});let l=globalThis;function m(){return l.__nomrehDatabase||(l.__nomrehDatabase=function(){let a=new i(g().join(k,"nomreh.db"));a.pragma("journal_mode = WAL"),a.pragma("foreign_keys = ON"),a.pragma("busy_timeout = 5000"),a.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin', 'teacher', 'reviewer')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS provider_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      encrypted_api_key TEXT NOT NULL,
      key_hint TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL,
      updated_by TEXT REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS api_network_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      plan TEXT NOT NULL CHECK(plan IN ('free', 'pro')),
      dns_primary TEXT NOT NULL,
      dns_secondary TEXT NOT NULL,
      transport TEXT NOT NULL DEFAULT 'dns' CHECK(transport IN ('dns', 'official-vm')),
      enabled INTEGER NOT NULL DEFAULT 0,
      encrypted_update_url TEXT NOT NULL DEFAULT '',
      update_url_source TEXT NOT NULL DEFAULT 'manual',
      encrypted_account_key TEXT NOT NULL DEFAULT '',
      account_login TEXT NOT NULL DEFAULT '',
      account_name TEXT NOT NULL DEFAULT '',
      account_authenticated_at TEXT,
      selected_order_id INTEGER,
      selected_order_label TEXT NOT NULL DEFAULT '',
      selected_order_due TEXT NOT NULL DEFAULT '',
      last_test_status TEXT NOT NULL DEFAULT 'idle',
      last_test_message TEXT NOT NULL DEFAULT '',
      last_tested_at TEXT,
      last_test_latency_ms INTEGER,
      last_activated_at TEXT,
      updated_at TEXT NOT NULL,
      updated_by TEXT REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS v2ray_settings (
      id INTEGER PRIMARY KEY CHECK(id = 1),
      enabled INTEGER NOT NULL DEFAULT 0,
      selected_config_id TEXT,
      last_test_status TEXT NOT NULL DEFAULT 'idle',
      last_test_message TEXT NOT NULL DEFAULT '',
      last_tested_at TEXT,
      updated_at TEXT NOT NULL,
      updated_by TEXT REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS v2ray_configs (
      id TEXT PRIMARY KEY,
      slot INTEGER NOT NULL,
      protocol TEXT NOT NULL,
      encrypted_config TEXT NOT NULL,
      fingerprint TEXT NOT NULL UNIQUE,
      last_test_status TEXT NOT NULL DEFAULT 'idle',
      last_error_code TEXT,
      last_latency_ms INTEGER,
      last_tested_at TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_v2ray_configs_slot ON v2ray_configs(slot);
    CREATE TABLE IF NOT EXISTS workspaces (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      data_json TEXT NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS ai_jobs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      submission_id TEXT,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      status TEXT NOT NULL,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      latency_ms INTEGER NOT NULL DEFAULT 0,
      error TEXT,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_ai_jobs_user ON ai_jobs(user_id);
    CREATE INDEX IF NOT EXISTS idx_ai_jobs_created ON ai_jobs(created_at);
  `);let b=new Set(a.prepare("PRAGMA table_info(api_network_settings)").all().map(a=>a.name));for(let[c,d]of[["transport","TEXT NOT NULL DEFAULT 'dns'"],["update_url_source","TEXT NOT NULL DEFAULT 'manual'"],["encrypted_account_key","TEXT NOT NULL DEFAULT ''"],["account_login","TEXT NOT NULL DEFAULT ''"],["account_name","TEXT NOT NULL DEFAULT ''"],["account_authenticated_at","TEXT"],["selected_order_id","INTEGER"],["selected_order_label","TEXT NOT NULL DEFAULT ''"],["selected_order_due","TEXT NOT NULL DEFAULT ''"]])b.has(c)||a.exec(`ALTER TABLE api_network_settings ADD COLUMN ${c} ${d}`);if(a.prepare("PRAGMA table_info(v2ray_configs)").all().some(a=>"last_error_code"===a.name)||a.exec("ALTER TABLE v2ray_configs ADD COLUMN last_error_code TEXT"),a.prepare("PRAGMA table_info(workspaces)").all().some(a=>"revision"===a.name)||a.exec("ALTER TABLE workspaces ADD COLUMN revision INTEGER NOT NULL DEFAULT 0"),a.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(new Date().toISOString()),0===a.prepare("SELECT COUNT(*) AS count FROM users").get().count){let b=new Date().toISOString();a.transaction(()=>{a.prepare(`INSERT INTO users (id, username, display_name, password_hash, role, active, created_at)
        VALUES (?, ?, ?, ?, 'admin', 1, ?)`).run((0,d.randomUUID)(),process.env.NOMREH_ADMIN_USERNAME||"admin","مدیر سامانه",j(process.env.NOMREH_ADMIN_PASSWORD||"Admin@1405"),b),a.prepare(`INSERT INTO users (id, username, display_name, password_hash, role, active, created_at)
        VALUES (?, ?, ?, ?, 'teacher', 1, ?)`).run((0,d.randomUUID)(),process.env.NOMREH_TEACHER_USERNAME||"teacher","معلم نمونه",j(process.env.NOMREH_TEACHER_PASSWORD||"Teacher@1405"),b)})()}return a}()),l.__nomrehDatabase}function n(a){return`${a}_${(0,d.randomUUID)()}`}}};